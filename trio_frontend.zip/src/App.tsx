import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import MainLayout from "./layout/mainLayout";
import MyFile from './pages/file';
import Masters from './pages/masters';
import Receipe from './pages/receipe';
import Report from './pages/report';
import Dashboard from './pages/dashboard';
import Stockreport from './pages/stock_report';
import Inventory from './pages/inventory';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<MainLayout />}>
          <Route path="dashboard" element={<Dashboard />} />
          <Route path="master" element={<Masters />} />
          <Route path="inventory_master" element={<MyFile />} />
          <Route path="inventory" element={<Inventory />} />
          <Route path="receipe" element={<Receipe />} />
          <Route path="stock_report" element={<Stockreport />} />
          <Route path="report" element={<Report />} />
        </Route>
      </Routes>
    </Router>
  );
}

export default App;
