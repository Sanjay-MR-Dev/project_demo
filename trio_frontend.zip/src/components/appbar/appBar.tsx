import * as React from 'react';
import {
    AppBar, Box, Toolbar, IconButton, Typography, Menu, MenuItem, ListItemIcon, Divider
} from '@mui/material';
import MenuIcon from '@mui/icons-material/Menu';
import AccountCircle from '@mui/icons-material/AccountCircle';
import Lock from '@mui/icons-material/Lock';
import Logout from '@mui/icons-material/Logout';
import AppBarImage from '../../assets/7_Logo.png';

interface Props {
    onMenuClick: () => void;
    drawerOpen: boolean;
    collapsed: boolean;
}



const AppBars: React.FC<Props> = ({ onMenuClick, drawerOpen, collapsed }) => {
    const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
    const menuOpen = Boolean(anchorEl);

    const drawerWidth = drawerOpen ? (collapsed ? 80 : 240) : 0;

    const handleMenuClick = (event: React.MouseEvent<HTMLElement>): void => {
        setAnchorEl(event.currentTarget);
    };

    const handleClose = (): void => {
        setAnchorEl(null);
    };

    const handleChangePassword = (): void => {
        handleClose();
    };

    const handleLogout = (): void => {
        handleClose();
    };

    return (
        <Box>
            <AppBar
                position="fixed"
                sx={{
                    ml: `${drawerWidth}px`,
                    width: `calc(100% - ${drawerWidth}px)`,
                    transition: 'margin 0.3s, width 0.3s',
                    backgroundColor: 'white',
                }}
            >

                <Toolbar sx={{ display: 'flex', justifyContent: 'space-between' }}>
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                        <img
                            src={AppBarImage}
                            alt="App Logo"
                            style={{ width: 70, height: 35, marginRight: 8 }}
                        />
                        <IconButton
                            size="large"
                            edge="start"
                            color="default"
                            aria-label="menu"
                            onClick={onMenuClick}
                            sx={{ ml: 1 }}
                        >
                            <MenuIcon sx={{ color: 'black' }} />
                        </IconButton>
                    </Box>

                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                        <Box
                            sx={{
                                display: 'flex',
                                alignItems: 'center',
                                cursor: 'pointer',
                                bgcolor: menuOpen ? 'ghostwhite' : 'transparent',
                                borderRadius: 10,
                                transition: 'background-color 0.2s',
                                px: 1,
                            }}
                            onClick={handleMenuClick}
                        >
                            <Typography
                                variant="subtitle1"
                                sx={{
                                    marginRight: 1,
                                    color: 'black',
                                    userSelect: 'none',
                                    textAlign: 'left'
                                }}
                            >
                                Trio-s Software Consultancy Pvt Ltd
                            </Typography>
                            <IconButton
                                size="large"
                                edge="end"
                                color="default"
                                sx={{ p: 0 }}
                            >
                                <AccountCircle sx={{ fontSize: 40, color: 'black' }} />
                            </IconButton>
                        </Box>
                        <Menu
                            anchorEl={anchorEl}
                            open={menuOpen}
                            onClose={handleClose}
                            anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
                            transformOrigin={{ vertical: 'top', horizontal: 'right' }}
                            PaperProps={{
                                sx: {
                                    borderRadius: 3,
                                    minWidth: 180,
                                    boxShadow: '0px 4px 16px rgba(163, 36, 36, 0.08)',
                                    mt: 1,
                                    ml: -2,
                                    backgroundColor: '#d5d0d0ff',
                                },
                            }}
                        >
                            <MenuItem onClick={handleChangePassword} sx={{ borderRadius: 2, mx: 1, my: 0.5 }}>
                                <ListItemIcon>
                                    <Lock fontSize="small" />
                                </ListItemIcon>
                                Change Password
                            </MenuItem>
                            <Divider sx={{ my: 0.5 }} />
                            <MenuItem onClick={handleLogout} sx={{ borderRadius: 2, mx: 1, my: 0.5 }}>
                                <ListItemIcon>
                                    <Logout fontSize="small" />
                                </ListItemIcon>
                                Logout
                            </MenuItem>
                        </Menu>
                    </Box>
                </Toolbar>
            </AppBar>
        </Box>
    );
};

export default AppBars;