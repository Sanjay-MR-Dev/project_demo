import * as React from 'react';
import {Drawer,Box,List,ListItem,
    ListItemIcon,ListItemButton,ListItemText,Switch,FormControlLabel
} from '@mui/material';
import { useNavigate, useLocation } from 'react-router-dom';
import DescriptionIcon from '@mui/icons-material/Description';
import DashboardIcon from '@mui/icons-material/Dashboard';
import AssessmentIcon from '@mui/icons-material/Assessment';
import DrawerLogo from '../../assets/7_Logo.png';
import AutoStoriesIcon from '@mui/icons-material/AutoStories';
import BreakfastDiningIcon from '@mui/icons-material/BreakfastDining';
import WarehouseIcon from '@mui/icons-material/Warehouse';
import ViewListIcon from '@mui/icons-material/ViewList';
import { drawerStyles } from '../../css/style';

interface Props {
    collapsed: boolean;
    toggleCollapse: () => void;
    isMobile: boolean;
    onCloseDrawer?: () => void;
}

interface DrawerItem {
    text : string;
    path : string;
    icon : React.ReactElement;
}


const Drawers: React.FC<Props> = ({ collapsed, toggleCollapse, isMobile, onCloseDrawer }) => {
    const navigate = useNavigate();
    const location = useLocation();
    const classes = drawerStyles({ collapsed });

    const items:DrawerItem[] = [
        { text: 'Dashboard', path: '/dashboard', icon: <DashboardIcon /> },
        { text: 'Master', path: '/master', icon: <ViewListIcon /> },
        { text: 'Inventory Master', path: '/inventory_master', icon: <WarehouseIcon /> },
        { text: 'Inventory', path: '/inventory', icon: <DescriptionIcon /> },
        { text: 'Receipe', path: '/receipe', icon: <BreakfastDiningIcon /> },
        { text: 'Stock Report', path: '/stock_report', icon: <AutoStoriesIcon /> },
        { text: 'Report', path: '/report', icon: <AssessmentIcon /> },

    ];

    const handleNavigate = (path: string) => {
        navigate(path);
        if (isMobile && onCloseDrawer) {
            onCloseDrawer();
        }
    };

    return (
        <Drawer
            anchor="left"
            variant="permanent"
            open
            className={classes.drawerSx}
        >
            <Box
                className={classes.drawerHeaderSx}
            >
                <Box className={classes.drawerLogoSx}>
                    <img
                        src={DrawerLogo}
                        alt="App Logo"
                        className={classes.drawerLogoImg}
                    />
                </Box>

                {!isMobile && (
                    <FormControlLabel control={
                        <Switch checked={!collapsed} onChange={toggleCollapse} color='default' />
                    }
                        label=""
                    />
                )}
            </Box>

            <List>
                {items.map((item) => (
                    <ListItem
                        key={item.text}
                        disablePadding
                        className={classes.drawerListItemSx}
                    >
                        <ListItemButton
                            selected={location.pathname === item.path}
                            onClick={() => handleNavigate(item.path)}
                            className={classes.drawerListItemButtonSx}
                        >
                            <ListItemIcon
                                className={classes.drawerListItemIconSx}
                            >
                                {item.icon}
                            </ListItemIcon>
                            {!collapsed && <ListItemText primary={item.text} />}
                        </ListItemButton>
                    </ListItem>
                ))}
            </List>
        </Drawer>
    );
};

export default Drawers;

