import { createTheme, responsiveFontSizes } from '@mui/material/styles';


let theme = createTheme({
  palette: {
    mode: 'light',
    background: {
      default: '#f8f9fa',
    },
    primary: {
      main: '#0088cc',
    },
    
  },
  typography: {
    h5: {
      fontSize: '1.5rem',
      fontStyle: 'Poppins, Roboto, sans-serif',
      '@media (max-width:600px)': {
        fontSize: '1.2rem',
      },
    },
    subtitle2: {
      fontSize: '0.875rem',
      '@media (max-width:600px)': {
        fontSize: '0.75rem',
      },
    },
    button: {
      fontSize: '0.875rem',
      '@media (max-width:600px)': {
        fontSize: '0.75rem',
      },
    },
  },
  components: {
    MuiButton: {
      styleOverrides: {
        root: ({ theme }) => ({
          padding: '6px 16px',
          backgroundColor: theme.palette.primary.main,
          color: '#fff',
          '&:hover': {
            backgroundColor: theme.palette.primary,
          },
          '@media (max-width:600px)': {
            padding: '4px 10px',
            minWidth: '80px',
          },
        }),
      },
    },
    MuiDrawer: {
      styleOverrides: {
        paper: ({ theme }) => ({
          backgroundColor: theme.palette.primary.main,
          color: '#fff',
        }),
      },
    },
    MuiListItemIcon: {
      styleOverrides: {
        root: {
          color: '#fff',
        },
      },
    },
    MuiIconButton: {
      styleOverrides: {
        root: {
          color: '#fff',
        },
      },
    },
  },
});

theme = responsiveFontSizes(theme);

export default theme;
