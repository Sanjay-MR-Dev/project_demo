
import { makeStyles } from '@mui/styles';
import { SxProps,Theme } from '@mui/material/';


interface StyleProps {
    collapsed: boolean;
}

export const drawerStyles = makeStyles({
    drawerSx: (props: StyleProps) => ({
        width: props.collapsed ? 70 : 240,
        flexShrink: 0,
        '& .MuiDrawer-paper': {
            width: props.collapsed ? 80 : 240,
            transition: 'width 0.3s',
            boxSizing: 'border-box',
            overflowX: 'hidden',
            color: '#fff',
        },
    }),
    drawerHeaderSx: (props: StyleProps) => ({
        display: 'flex',
        alignItems: 'center',
        justifyContent: props.collapsed ? 'center' : 'space-between',
        px: 2,
        py: 2,
    }),
    drawerLogoSx: (props: StyleProps) => ({
        display: 'flex',
        alignItems: 'center',
    }),
    drawerLogoImg: (props: StyleProps) => ({
        width: 120,
        height: 40,
        marginRight: props.collapsed ? 0 : 5,
    }),
    drawerListItemSx: (props: StyleProps) => ({
        justifyContent: props.collapsed ? 'center' : 'flex-start',
    }),
    drawerListItemButtonSx: (props: StyleProps) => ({
        pl: props.collapsed ? 2 : 3,
    }),
    drawerListItemIconSx: (props: StyleProps) => ({
        color: 'white',
        minWidth: props.collapsed ? 0 : 40,
        justifyContent: 'center',
    }),
})

export const fileStyles: { [key: string]: SxProps<Theme> } = ({
    headerBox: {
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        mb: 4,
        backgroundColor: '#e6e6e6ff',
        padding: 2,
        borderRadius: 2,
        boxShadow: 'unset'
    },
    titleText: {
        fontWeight: 'bold',
        fontFamily: 'sans-serif',
        letterSpacing: 2,
        fontSize: '1.2rem',
    },
    addButton: {
        borderRadius: 5
    },
    tableHeader: {
        backgroundColor: '#e6e7e8ff',
        color: 'black',
    },
    modalBox: {
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        width: { xs: '90%', sm: 300, md: '500px', lg: '600px' },
        maxWidth: '100vw',
        bgcolor: 'background.paper',
        borderRadius: 2,
        boxShadow: 24,
        p: 4,
    },
    inputField: {
        mb: 2
    },
    checkboxStack: {
        mb: 5
    }
});