
import React from 'react';
import { Outlet } from 'react-router-dom';
import { useMediaQuery, useTheme, Drawer, Box } from '@mui/material';
import AppBars from '../components/appbar/appBar';
import Drawers from '../components/drawer/drawer';

const MainLayout: React.FC = () => {
  const [drawerOpen, setDrawerOpen] = React.useState<boolean>(false);
  const [collapsed, setCollapsed] = React.useState<boolean>(false);
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));

  const handleAppBarMenuClick = () => {
    if (!drawerOpen) {
      setDrawerOpen(true);
      setCollapsed(false);
    } else {
      setDrawerOpen(false);
    }
  };

  const toggleCollapse = (): void => {
    setCollapsed((prev) => !prev);
  };

  const handleDrawerClose = (): void => {
    setDrawerOpen(false);
  };

  const drawerWidth = !drawerOpen ? 0 : collapsed ? 70 : 240;

  return (
    <>
      <AppBars
        onMenuClick={handleAppBarMenuClick}
        drawerOpen={!isMobile && drawerOpen}
        collapsed={!isMobile && collapsed}
      />

      {drawerOpen &&
        (isMobile ? (
          <Drawer
            anchor="left"
            open={drawerOpen}
            onClose={handleDrawerClose}
            ModalProps={{ keepMounted: true }}
            sx={{
              '& .MuiDrawer-paper': {
                width: collapsed ? 70 : 240,
              },
            }}
          >
            <Drawers
              collapsed={collapsed}
              toggleCollapse={toggleCollapse}
              isMobile={isMobile}
              onCloseDrawer={handleDrawerClose}
            />
          </Drawer>
        ) : (
          <div style={{ position: 'absolute', top: 64, zIndex: 1200 }}>
            <Drawers
              collapsed={collapsed}
              toggleCollapse={toggleCollapse}
              isMobile={isMobile}
            />
          </div>
        ))}

      <Box
        component="main"
        sx={{
          marginTop: '64px',
          marginLeft: !isMobile ? `${drawerWidth}px` : 0,
          padding: 2,
          transition: 'margin 0.3s',
        }}
      >
        <Outlet />
      </Box>
    </>
  );
};

export default MainLayout;