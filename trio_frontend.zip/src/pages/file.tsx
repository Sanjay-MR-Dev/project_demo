import React from 'react';
import { MaterialReactTable, MRT_ColumnDef } from 'material-react-table';
import {
    Box, Modal, Typography, Button,
    TextField, Checkbox, FormControlLabel, FormGroup,
    Stack
} from '@mui/material';
import ListIcon from '@mui/icons-material/Add';
import { fileStyles } from '../css/style';


interface RMItem {
    item : string;
    itemGroup : string;
    isTaxable : string;
    isStockable : string;
}

const data: RMItem[] = [
    { item: "Potato", itemGroup: "Vegetable", isTaxable: "Yes", isStockable: "Yes" },
    { item: "Tomato", itemGroup: "Vegetable", isTaxable: "Yes", isStockable: "Yes" },
    { item: "Onion", itemGroup: "Vegetable", isTaxable: "No", isStockable: "No" },
    { item: "Apple", itemGroup: "Fruit", isTaxable: "Yes", isStockable: "Yes" },
]

const columns: MRT_ColumnDef<RMItem>[] = [
    { accessorKey: 'item', header: 'Item' },
    { accessorKey: 'itemGroup', header: 'Item Group' },
    { accessorKey: 'isTaxable', header: 'Is Taxable' },
    { accessorKey: 'isStockable', header: 'Is Stockable' },
];

const MyFile: React.FC = () => {
    const [open, setOpen] = React.useState<boolean>(false);
     const classes = fileStyles;


    return (
        <Box>
            <Box
                sx = {classes.headerBox}
                
            >
                <Typography
                    variant="h4"
                    color="black"
                     sx = {classes.titleText}
                >
                    RM Item Master
                </Typography>

                <Button
                    variant="contained"
                    startIcon={<ListIcon />}
                    sx = {classes.addButton}
                    onClick={() => setOpen(true)}
                >
                    Add RM Item
                </Button>
            </Box>

            <MaterialReactTable
                columns={columns}
                data={data}
                enableFullScreenToggle={false}
                enableDensityToggle={false}
                enableColumnActions={false}
                enableHiding={false}
                muiTableHeadCellProps={{
                    sx: {
                    backgroundColor: '#e6e7e8ff',
                    color: 'black',
                }}}
                />

            <Modal open={open} onClose={() => setOpen(false)}>
                <Box
                   sx = {classes.modalBox}
                >
                    <Typography variant='h6' fontWeight='bold' sx = {classes.inputField}>
                        Add RM Item
                    </Typography>

                    <Typography variant='subtitle2' color='black'>
                        Item
                    </Typography>

                    <TextField
                        name='Item'
                        fullWidth
                        sx = {classes.checkboxStack}
                    />

                    <Typography variant='subtitle2' color='black'>
                        Item Group
                    </Typography>

                    <TextField
                        name='Item Group'
                        fullWidth
                        sx={{ mb: 2 }}
                    />
                    <FormGroup>
                        <Stack spacing={3} direction='row' sx={{ mb: 5 }}>
                            <FormControlLabel control={<Checkbox defaultChecked />} label="Taxable" />
                            <FormControlLabel control={<Checkbox defaultChecked />} label="Stockable" />
                        </Stack>

                    </FormGroup>

                    <Stack spacing={2} direction='row'>
                        <Button
                            variant='contained'
                            onClick={() => setOpen(false)}>
                            Submit
                        </Button>
                        <Button
                            variant='contained'
                            sx={{ backgroundColor: '#d32f2f', '&:hover': { backgroundColor: '#b71c1c' } }}
                            onClick={() => setOpen(false)}>
                            Close
                        </Button>
                    </Stack>
                </Box>

            </Modal>
        </Box>
    );
}
export default MyFile;



