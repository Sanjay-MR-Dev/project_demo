import React from 'react';


const Inventory: React.FC = () => {  
    return(
        <div></div>
    )};

export default Inventory;