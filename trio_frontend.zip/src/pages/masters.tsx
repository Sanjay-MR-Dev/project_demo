import React from 'react';


const Masters: React.FC = () => {  
    return(
        <div></div>
    )};

export default Masters;