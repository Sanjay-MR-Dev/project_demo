import React from 'react';


const Receipe: React.FC = () => {  
    return(
        <div></div>
    )};

export default Receipe;