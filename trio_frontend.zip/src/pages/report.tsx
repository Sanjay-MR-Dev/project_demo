import React from 'react';


const Report: React.FC = () => {  
    return(
        <div></div>
    )};

export default Report;