import React from 'react';


const Stockreport: React.FC = () => {  
    return(
        <div></div>
    )};

export default Stockreport;